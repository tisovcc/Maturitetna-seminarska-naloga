package izdelavaTetris;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Kocka {
	public Gradnik g []= new Gradnik[4];		//tabela 1
	public Gradnik temp[] = new Gradnik[4];		//tabela 2
	int spuscanjeStevec = 0;
	int smer = 1;
	boolean zadetaSpodnja, zadetaDesna, zadetaLeva;
	boolean active = true;
	public boolean deactivating;
	int stevec = 0;
	
	
	public void pobarvaj(Color barva) {
		for(int i = 0; i < 4; i++) {
			g[i] = new Gradnik(barva);
			temp[i] = new Gradnik(barva);
		}
	}
	public void nastaviXY(int x, int y) {}		//pustimo prazno, ker overridamo
	public void posodobiXY(int smer) {
		trkObRotiranju();
		if(zadetaLeva == false && zadetaDesna == false && zadetaSpodnja == false) {
			this.smer = smer;
			g[0].x = temp[0].x;
			g[0].y = temp[0].y;
			g[1].x = temp[1].x;
			g[1].y = temp[1].y;
			g[2].x = temp[2].x;
			g[2].y = temp[2].y;
			g[3].x = temp[3].x;
			g[3].y = temp[3].y;
		}
	}
	
	public void trkObPremikanju() {
		zadetaSpodnja = false;
		zadetaDesna = false;
		zadetaLeva = false;
		
		trkObKocki();
		
		//dno
		for(int i = 0; i < g.length; i++) {
			if(g[i].y + Gradnik.velikost == Igra.dol) {
				zadetaSpodnja = true;
			}
		}
		//desna stena
		for(int i = 0; i < g.length; i++) {
			if(g[i].x + Gradnik.velikost == Igra.desno) {
				zadetaDesna = true;
			}
		}
		//leva stena
		for(int i = 0; i < g.length; i++) {
			if(g[i].x == Igra.levo) {
				zadetaLeva = true;
			}
		}
	}
	
	public void trkObRotiranju() {
		zadetaSpodnja = false;
		zadetaDesna = false;
		zadetaLeva = false;
		
		trkObKocki();
		
		//dno
		for(int i = 0; i < g.length; i++) {
			if(temp[i].y + Gradnik.velikost > Igra.dol) {
				zadetaSpodnja = true;
				System.out.println("zadetaSpodnja");
			}
		}
		//desna stena
		for(int i = 0; i < g.length; i++) {
			if(temp[i].x + Gradnik.velikost > Igra.desno) {
				zadetaDesna = true;
				System.out.println("zadetaDesna");
			}
		}
		//leva stena
		for(int i = 0; i < g.length; i++) {
			if(temp[i].x < Igra.levo) {
				zadetaLeva = true;
				System.out.println("zadetaLeva");
			}
		}
	}
	
	public void trkObKocki() {
		for(int i = 0; i < Igra.stareKocke.size(); i++) {
			int X = Igra.stareKocke.get(i).x;
			int Y = Igra.stareKocke.get(i).y;
			
			//preglej spodaj
			for(int j = 0; j < g.length; j++) {
				if(g[j].y + Gradnik.velikost == Y && g[j].x == X) {
					zadetaSpodnja = true;
				}
			}
			//preglej levo
			for(int j = 0; j < g.length; j++) {
				if(g[j].y == Y && g[j].x - Gradnik.velikost == X) {
					zadetaLeva = true;
				}
			}
			//preglej desno
			for(int j = 0; j < g.length; j++) {
				if(g[j].y == Y && g[j].x + Gradnik.velikost == X) {
					zadetaDesna = true;
				}
			}
			
		}
	}
	
	
	public void update() {
		//pred deaktivacijo pocakamo
		if(deactivating == true) {
			stevec++;
			if(stevec == 45) {
				stevec = 0;
				trkObPremikanju();
				if(zadetaSpodnja == true) {
					active = false;
				}
			}
		}
		
		//mehanizem za premikanje
		trkObPremikanju();
		if(Tipkovnica.dol == true) {		//premakni dol
			if(zadetaSpodnja == false) {
				for(int i = 0; i < 4; i++) {
					g[i].y += Gradnik.velikost;
				}
				Tipkovnica.dol = false;			//ponastavimo
			}
		}
		if(Tipkovnica.desno == true) {		//premakni desno
			if(zadetaDesna == false) {
				for(int i = 0; i < 4; i++) {
					g[i].x += Gradnik.velikost;
				}
				Tipkovnica.desno = false;		//ponastavimo
			}
		}
		if(Tipkovnica.levo == true) {		//premakni levo
			if(zadetaLeva == false) {
				for(int i = 0; i < 4; i++) {
					g[i].x -= Gradnik.velikost;
				}
				Tipkovnica.levo = false;		//ponastavimo
			}
		}
		
		//mehanizem za rotacijo
		if(Tipkovnica.gor == true) {
			switch(smer) {
				case 1: dobiSmer2(); break;
				case 2: dobiSmer3(); break;
				case 3: dobiSmer4(); break;
				case 4: dobiSmer1(); break;
			}
			Tipkovnica.gor = false;	
		}
		if(zadetaSpodnja == true) {
			deactivating = true;
		}
		else {
			//mehanizem za spuscanje
			spuscanjeStevec++;
			if(spuscanjeStevec == Igra.intervalSpuscanja) {
				g[0].y += Gradnik.velikost;		//Lik premaknemo navzdol za eno velikost gradnika
				g[1].y += Gradnik.velikost;
				g[2].y += Gradnik.velikost;
				g[3].y += Gradnik.velikost;
				spuscanjeStevec = 0;
			}
		}
	}
	public void narisi(Graphics2D a) {
		a.setColor(g[0].barva);
		a.fillRect(g[0].x + 2, g[0].y + 2, Gradnik.velikost - 4, Gradnik.velikost - 4);
		a.fillRect(g[1].x + 2, g[1].y + 2, Gradnik.velikost - 4, Gradnik.velikost - 4);
		a.fillRect(g[2].x + 2, g[2].y + 2, Gradnik.velikost - 4, Gradnik.velikost - 4);
		a.fillRect(g[3].x + 2, g[3].y + 2, Gradnik.velikost - 4, Gradnik.velikost - 4);
	}
	
	public void dobiSmer1() {}		//pustimo prazno, ker overridamo
	public void dobiSmer2() {}		//
	public void dobiSmer3() {}		//
	public void dobiSmer4() {}		//
	
}

class Gradnik extends Rectangle{
	public int x, y;			//x in y koordinata
	public static final int velikost = 30;	//velikost enega gradnika
	public Color barva;			//barva gradnika
	
	public Gradnik(Color b) {		//vpisemo barvo
		this.barva = b;
	}
	
	public void narisi(Graphics2D g) {
		g.setColor(barva);
		g.fillRect(x + 2, y + 2, velikost - 4, velikost - 4);
	}
}

// Tetris liki
class Z1 extends Kocka{
	public Z1() {
		pobarvaj(Color.red);
	}
	public void nastaviXY(int x, int y) {
		//   1
		// 2 0
		// 3
		
		g[0].x = x;						//x0
		g[0].y = y;						//y0
		g[1].x = x;						//x1
		g[1].y = y - Gradnik.velikost;	//y1
		g[2].x = x - Gradnik.velikost;	//x2
		g[2].y = y;						//y2
		g[3].x = x - Gradnik.velikost;	//x3
		g[3].y = y + Gradnik.velikost;	//y4
	}
	public void dobiSmer1() {
		//   1
		// 2 0
		// 3
		
		temp[0].x = g[0].x;
		temp[0].y = g[0].y;
		temp[1].x = g[0].x;
		temp[1].y = g[0].y - Gradnik.velikost;
		temp[2].x = g[0].x - Gradnik.velikost;
		temp[2].y = g[0].y;
		temp[3].x = g[0].x - Gradnik.velikost;
		temp[3].y = g[0].y + Gradnik.velikost;
		
		posodobiXY(1);
	}
	public void dobiSmer2() {
		// 3 2
		//   0 1
		
		temp[0].x = g[0].x;
		temp[0].y = g[0].y;
		temp[1].x = g[0].x + Gradnik.velikost;
		temp[1].y = g[0].y;
		temp[2].x = g[0].x;
		temp[2].y = g[0].y - Gradnik.velikost;
		temp[3].x = g[0].x - Gradnik.velikost;
		temp[3].y = g[0].y - Gradnik.velikost;
		
		posodobiXY(2);
	}
	public void dobiSmer3() {dobiSmer1();}
	public void dobiSmer4() {dobiSmer2();}
}

//=====================================================================================//

class Z2 extends Kocka{
	public Z2() {
		pobarvaj(Color.blue);
	}
	public void nastaviXY(int x, int y) {
		// 1
		// 0 2
		//   3
		
		g[0].x = x;						g[0].y = y;
		g[1].x = x; 					g[1].y = y - Gradnik.velikost;
		g[2].x = x + Gradnik.velikost;  g[2].y = y;
		g[3].x = x + Gradnik.velikost;  g[3].y = y + Gradnik.velikost;
	}
	public void dobiSmer1() {
		// 1
		// 0 2
		//   3
		
		temp[0].x = g[0].x;
		temp[0].y = g[0].y;
		temp[1].x = g[0].x;
		temp[1].y = g[0].y - Gradnik.velikost;
		temp[2].x = g[0].x + Gradnik.velikost;
		temp[2].y = g[0].y;
		temp[3].x = g[0].x + Gradnik.velikost;
		temp[3].y = g[0].y + Gradnik.velikost;		
		
		posodobiXY(1);
	}
	public void dobiSmer2() {
		//   0 1
		// 3 2
		
		temp[0].x = g[0].x;
		temp[0].y = g[0].y;
		temp[1].x = g[0].x + Gradnik.velikost;
		temp[1].y = g[0].y;
		temp[2].x = g[0].x;
		temp[2].y = g[0].y + Gradnik.velikost;
		temp[3].x = g[0].x - Gradnik.velikost;
		temp[3].y = g[0].y + Gradnik.velikost;
		
		posodobiXY(2);
	}
	public void dobiSmer3() {dobiSmer1();}
	public void dobiSmer4() {dobiSmer2();}
}

//=====================================================================================//

class L1 extends Kocka{
	public L1() {
		pobarvaj(Color.yellow);
	}
	public void nastaviXY(int x, int y) {
		//   1
		//   0
		// 3 2
		
		g[0].x = x; 					g[0].y = y;
		g[1].x = x; 					g[1].y = y - Gradnik.velikost;
		g[2].x = x; 					g[2].y = y + Gradnik.velikost;
		g[3].x = x - Gradnik.velikost;  g[3].y = y + Gradnik.velikost;
	}
	public void dobiSmer1() {
		//   1
		//   0
		// 3 2
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x; 					temp[1].y = g[0].y - Gradnik.velikost;
		temp[2].x = g[0].x; 					temp[2].y = g[0].y + Gradnik.velikost;
		temp[3].x = g[0].x - Gradnik.velikost;  temp[3].y = g[0].y + Gradnik.velikost;
		
		posodobiXY(1);
	}
	public void dobiSmer2() {
		//3
		//2 0 1
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x + Gradnik.velikost;  temp[1].y = g[0].y;
		temp[2].x = g[0].x - Gradnik.velikost;  temp[2].y = g[0].y;
		temp[3].x = g[0].x - Gradnik.velikost;  temp[3].y = g[0].y - Gradnik.velikost;
		
		posodobiXY(2);
	}
	public void dobiSmer3() {
		//2 3
		//0
		//1
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x; 					temp[1].y = g[0].y + Gradnik.velikost;
		temp[2].x = g[0].x; 					temp[2].y = g[0].y - Gradnik.velikost;
		temp[3].x = g[0].x + Gradnik.velikost;  temp[3].y = g[0].y - Gradnik.velikost;
		
		posodobiXY(3);
	}
	public void dobiSmer4() {
		//1 0 2
		//    3
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x - Gradnik.velikost;  temp[1].y = g[0].y;
		temp[2].x = g[0].x + Gradnik.velikost;  temp[2].y = g[0].y;
		temp[3].x = g[0].x + Gradnik.velikost;  temp[3].y = g[0].y + Gradnik.velikost;
		
		posodobiXY(4);
	}
}

//=====================================================================================//

class L2 extends Kocka{
	public L2() {
		pobarvaj(Color.cyan);
	}
	public void nastaviXY(int x, int y) {
		// 1
		// 0
		// 2 3
		
		g[0].x = x; 					g[0].y = y;
		g[1].x = x; 					g[1].y = y - Gradnik.velikost;
		g[2].x = x; 					g[2].y = y + Gradnik.velikost;
		g[3].x = x + Gradnik.velikost;  g[3].y = y + Gradnik.velikost;
	}
	public void dobiSmer1() {
		// 1
		// 0
		// 2 3
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x; 					temp[1].y = g[0].y - Gradnik.velikost;
		temp[2].x = g[0].x; 					temp[2].y = g[0].y + Gradnik.velikost;
		temp[3].x = g[0].x + Gradnik.velikost;  temp[3].y = g[0].y + Gradnik.velikost;
		
		posodobiXY(1);
	}
	public void dobiSmer2() {
		// 2 0 1
		// 3
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x + Gradnik.velikost;  temp[1].y = g[0].y;
		temp[2].x = g[0].x - Gradnik.velikost;  temp[2].y = g[0].y;
		temp[3].x = g[0].x - Gradnik.velikost;  temp[3].y = g[0].y + Gradnik.velikost;
		
		posodobiXY(2);
	}
	public void dobiSmer3() {
		// 3 2
		//   0
		//   1
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x; 					temp[1].y = g[0].y + Gradnik.velikost;
		temp[2].x = g[0].x; 					temp[2].y = g[0].y - Gradnik.velikost;
		temp[3].x = g[0].x - Gradnik.velikost;  temp[3].y = g[0].y - Gradnik.velikost;
		
		posodobiXY(3);
	}
	public void dobiSmer4() {
		//     3
		// 1 0 2
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x - Gradnik.velikost;  temp[1].y = g[0].y;
		temp[2].x = g[0].x + Gradnik.velikost;  temp[2].y = g[0].y;
		temp[3].x = g[0].x + Gradnik.velikost;  temp[3].y = g[0].y - Gradnik.velikost;
		
		posodobiXY(4);
	}
}

//=====================================================================================//

class T extends Kocka{
	public T() {
		pobarvaj(Color.green);
	}
	public void nastaviXY(int x, int y) {
		// 1 0 3
		//	 2
		
		g[0].x = x; 					g[0].y = y;
		g[1].x = x - Gradnik.velikost;  g[1].y = y;
		g[2].x = x; 					g[2].y = y + Gradnik.velikost;
		g[3].x = x + Gradnik.velikost;  g[3].y = y;
	}
	public void dobiSmer1() {
		// 1 0 3
		//	 2
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x - Gradnik.velikost;  temp[1].y = g[0].y;
		temp[2].x = g[0].x; 					temp[2].y = g[0].y + Gradnik.velikost;
		temp[3].x = g[0].x + Gradnik.velikost;  temp[3].y = g[0].y;		
		
		posodobiXY(1);
	}
	public void dobiSmer2() {
		//   1
		// 2 0
		//   3
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x; 					temp[1].y = g[0].y - Gradnik.velikost;
		temp[2].x = g[0].x - Gradnik.velikost;  temp[2].y = g[0].y;
		temp[3].x = g[0].x; 					temp[3].y = g[0].y + Gradnik.velikost;		
		
		posodobiXY(2);
	}
	public void dobiSmer3() {
		//  2
		//3 0 1
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x + Gradnik.velikost;  temp[1].y = g[0].y;
		temp[2].x = g[0].x; 					temp[2].y = g[0].y - Gradnik.velikost;
		temp[3].x = g[0].x - Gradnik.velikost;  temp[3].y = g[0].y;		
		
		posodobiXY(3);
	}
	public void dobiSmer4() {
		//3
		//0 2
		//1
		
		temp[0].x = g[0].x; 					temp[0].y = g[0].y;
		temp[1].x = g[0].x; 					temp[1].y = g[0].y + Gradnik.velikost;
		temp[2].x = g[0].x + Gradnik.velikost;  temp[2].y = g[0].y;
		temp[3].x = g[0].x; 					temp[3].y = g[0].y - Gradnik.velikost;		
		
		posodobiXY(4);
	}
}

//=====================================================================================//

class Kvadrat extends Kocka{
	public Kvadrat() {
		pobarvaj(Color.magenta);
	}
	public void nastaviXY(int x, int y) {
		// 0 1
		// 2 3
		
		g[0].x = x;  					g[0].y = y;
		g[1].x = x + Gradnik.velikost;  g[1].y = y;
		g[2].x = x;  					g[2].y = y + Gradnik.velikost;
		g[3].x = x + Gradnik.velikost;  g[3].y = y + Gradnik.velikost;
	}
	public void dobiSmer1() {}
	public void dobiSmer2() {}
	public void dobiSmer3() {}
	public void dobiSmer4() {}
}

//=====================================================================================//

class Crta extends Kocka{
	public Crta() {
		pobarvaj(Color.pink);
	}
	public void nastaviXY(int x, int y) {
		// 1 0 2 3
		
		g[0].x = x;  					  g[0].y = y;
		g[1].x = x - Gradnik.velikost;    g[1].y = y;
		g[2].x = x + Gradnik.velikost;	  g[2].y = y;
		g[3].x = x + 2*Gradnik.velikost;  g[3].y = y;
	}
	public void dobiSmer1() {
		// 1 0 2 3
		
		temp[0].x = g[0].x;  					  temp[0].y = g[0].y;
		temp[1].x = g[0].x - Gradnik.velikost; 	  temp[1].y = g[0].y;
		temp[2].x = g[0].x + Gradnik.velikost; 	  temp[2].y = g[0].y;
		temp[3].x = g[0].x + 2*Gradnik.velikost;  temp[3].y = g[0].y;
		
		posodobiXY(1);
	}
	public void dobiSmer2() {
		// 1
		// 0
		// 2
		// 3
		
		temp[0].x = g[0].x;  temp[0].y = g[0].y;
		temp[1].x = g[0].x;  temp[1].y = g[0].y - Gradnik.velikost;
		temp[2].x = g[0].x;  temp[2].y = g[0].y + Gradnik.velikost;
		temp[3].x = g[0].x;  temp[3].y = g[0].y + 2*Gradnik.velikost;
		
		posodobiXY(2);
	}
	public void dobiSmer3() {dobiSmer1();}
	public void dobiSmer4() {dobiSmer2();}
}




