package izdelavaTetris;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Tipkovnica implements KeyListener{

	public static boolean gor, dol, levo, desno, pauza;
	
	@Override
	public void keyTyped(KeyEvent e) {}

	@Override
	public void keyPressed(KeyEvent e) {
		int code = e.getKeyCode();
		if(code == KeyEvent.VK_UP) {			//rotacija (gor)
			gor = true;
			System.out.println("gor");
		}
		if(code == KeyEvent.VK_DOWN) {			//dol
			dol = true;
			System.out.println("dol");
		}
		if(code == KeyEvent.VK_LEFT) {			//levo
			levo = true;
			System.out.println("levo");
		}
		if(code == KeyEvent.VK_RIGHT) {			//desno
			desno = true;
			System.out.println("desno");
		}
		if(code == KeyEvent.VK_ESCAPE) {		//pauza (esc)
			pauza = true;
			System.out.println("esc");
		}
		else {
			pauza = false;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {}
}
