package izdelavaTetris;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class Okno extends JPanel implements Runnable{
	public static final int dolzina = 1280;			//dolzina okna
	public static final int sirina = 720;				//visina okna
	
	final int FPS = 60;
	Thread gameThread;
	Igra igra;
	
	
	public Okno() {
		this.setPreferredSize(new Dimension(dolzina, sirina));			//velikost okna bo 1280 x 720
		this.setLayout(null);
		this.setBackground(Color.decode("#EDD6B6"));				//nastavimo barvo ozadja
		
		//KeyListener (tipkovnica)
		this.addKeyListener(new Tipkovnica());					//dodamo funkcijo tipkovnice
		this.setFocusable(true);
		
		igra = new Igra();
	}

	public void launchGame() {
		gameThread = new Thread(this);
		gameThread.start();
	}
	
	
	@Override
	public void run() {
		//1000000000 nanosek. => 1 sek. => na ekran narisemo vsakih 0,016 sek.
		double vmesniCas = 1000000000 / FPS;
		double naslednjiCas = System.nanoTime() + vmesniCas;  //naslednji cas risanja
		
		while(gameThread != null) {
			update();		//klice update()
			repaint();		//klice paintComponent()
			
			try {
				double ostalCas = naslednjiCas - System.nanoTime();
				ostalCas = ostalCas / 1000000000;		//pretvorimo v milisek.
				Thread.sleep((long) ostalCas);			//ustavimo gameloop
				naslednjiCas += vmesniCas;
				
			} catch (InterruptedException e) {e.printStackTrace();}
		}
	}
	
	public void update() {
		if(Tipkovnica.pauza != true && Igra.konec != true) {
			igra.posodobi();		//klicemo metodo posodobi
		}
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g1 = (Graphics2D) g;		//1D pretvorimo v 2D
		igra.narisi(g1);				//klicemo metodo narisi
	}
	
}






