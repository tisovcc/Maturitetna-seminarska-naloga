package izdelavaTetris;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Random;

public class Igra {

	//velikost igralne povrsine
	final int visina = 600;					//30x20
	final int sirina = 360;					//30x12
	public static int intervalSpuscanja = 120;
	public static int levo, desno, gor, dol;
	int raven = 1;
	int vrste, tocke;
	public static boolean konec = false;
	
	Kocka trenutnaKocka;
	final int startX, startY;
	
	Kocka naslednjaKocka;
	final int startXNaslednji, startYNaslednji;
	public static ArrayList<Gradnik> stareKocke = new ArrayList<>();
	
	Igra(){
		levo = (Okno.dolzina/2) - (sirina/2);	//koordinata levega roba
		desno = levo + sirina;				//koordinata desnega roba
		gor = 50;						//koordinata zgornjega roba
		dol = gor + visina;					//koordinata spodnjega roba
		
		startX = Okno.dolzina/2 - Gradnik.velikost;			//zacetna pozicija x
		startY = gor + Gradnik.velikost;		//zacetna pozicija y
		startXNaslednji = desno + 180;
		startYNaslednji = gor + 300;
		
		trenutnaKocka = izberiKocko();
		trenutnaKocka.nastaviXY(startX, startY);
		naslednjaKocka = izberiKocko();
		naslednjaKocka.nastaviXY(startXNaslednji, startYNaslednji);
		
	}
	
	public Kocka izberiKocko() {		//izberemo nakljucno kocko
		Kocka kocka = null;
		int i = new Random().nextInt(7);
		switch(i) {
		case 0: kocka = new Z1(); break;
		case 1: kocka = new Z2(); break;
		case 2: kocka = new L1(); break;
		case 3: kocka = new L2(); break;
		case 4: kocka = new T(); break;
		case 5: kocka = new Kvadrat(); break;
		case 6: kocka = new Crta(); break;
		}
		return kocka;					//vrnemo izbrano kocko
	}
	public void izbrisi() {
		int x = levo;
		int y = gor;
		int stevec = 0;
		int stevecVrst = 0;
		
		while(x < desno && y < dol) {
			
			for(int i = 0; i < stareKocke.size(); i++) {
				if(stareKocke.get(i).x == x && stareKocke.get(i).y == y) {
					stevec++;	//povecamo stevec ce na koordinatah x in y najdemo staro kocko
				}
			}
			x += Gradnik.velikost;
			
			if(x == desno) {
				if(stevec == 12) {		//ce je vrsta polna
					for(int i = stareKocke.size()-1; i > -1; i-- ) {
						if(stareKocke.get(i).y == y) {
							stareKocke.remove(i);		//vrsto izbrisemo
						}
					}
					stevecVrst++;
					vrste++;
					//povecamo hitrost spuscanja
					if(vrste % 10 == 0 && intervalSpuscanja > 1) {
						raven++;
						if(intervalSpuscanja > 20) {
							intervalSpuscanja -= 20;
						}
						else {
							intervalSpuscanja -= 1;
						}
					}
					
					for(int i = 0; i < stareKocke.size(); i++) {
						if(stareKocke.get(i).y < y) {
							stareKocke.get(i).y += Gradnik.velikost;
						}
					}
				}
				stevec = 0;
				x = levo;
				y += Gradnik.velikost;
			}
		}
		
		if(stevecVrst > 0) {
			tocke += 10 * raven * stevecVrst ;
			
		}
		
	}
	
	public void posodobi() {
		if(trenutnaKocka.active == false) {
			for(int i = 0; i < 4; i ++) {
				stareKocke.add(trenutnaKocka.g[i]);		//ce kocka ni aktivna jo dodamo v arraylist stareKocke
			}
			
			if(trenutnaKocka.g[0].x == startX && trenutnaKocka.g[0].y == startY) {	//ce se kocka ni premaknila iz zacetka
				konec = true;
			}
			
			trenutnaKocka.deactivating = false;		//ponastavimo deactivating
			trenutnaKocka = naslednjaKocka;				//zamenamo kocke
			trenutnaKocka.nastaviXY(startX, startY);		//in jim nastavimo koordiate
			naslednjaKocka = izberiKocko();
			naslednjaKocka.nastaviXY(startXNaslednji, startYNaslednji);
			
			izbrisi();		//preverimo ce lahko izbrisemo kaksno vrstico
		}
		else {
			trenutnaKocka.update();
		}
	}
	
	public void narisi(Graphics2D a) {
		a.setColor(Color.black);
		a.setStroke(new BasicStroke(4));
		a.setFont(new Font ("Arial", Font.BOLD, 30));
		
		a.drawRect(levo - 4, gor - 4, sirina + 8, visina + 8);
		a.drawRect(desno + 100, gor + 200, 200, 200);
		a.drawString("NASLEDNJI:", desno + 111, gor + 250);
		a.drawRect(levo - 350, gor + 150, 250, 300);
		a.drawString("RAVEN: " + raven, levo - 325, gor + 240);
		a.drawString("VRSTE: " + vrste, levo - 325, gor + 310);
		a.drawString("TOČKE: " + tocke, levo - 325, gor + 380);
		
		if(trenutnaKocka != null) {
			trenutnaKocka.narisi(a);
		}
		
		naslednjaKocka.narisi(a);
		
		for(int i = 0; i < stareKocke.size(); i++) {
			stareKocke.get(i).narisi(a);
		}
		
		a.setColor(Color.black);
		a.setFont(new Font ("Arial", Font.PLAIN, 50));
		if(konec == true) {
			a.drawString("KONEC IGRE", levo + 25, gor + 320);
		}
		else if(Tipkovnica.pauza == true) {
			a.drawString("PAVZA", levo + 100, gor + 320);
		}
		
		
		
	}
}




