package izdelavaTetris;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		
		JFrame frame = new JFrame("Tetris");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		
		Okno okno = new Okno();
		frame.add(okno);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		
		okno.launchGame();
	}
}