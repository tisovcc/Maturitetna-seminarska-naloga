/**
 * 
 */
/**
 * @author Ex
 *
 */
module izdelavaTetris {
	requires java.desktop;
}